package studentdatabaseapp;

import java.util.ArrayList;
import java.util.Scanner;

public class Student {
    private String firstName;
    private String lastName;
    private int year;
    private String studentID;
    private ArrayList<String> courses = new ArrayList<String>();
    private int tuitionBalance;
    private static int costOfCourse = 600;
    private static int id = 1000;

    public Student(){
        generateID();
    }

    public void setId(int id) {
        Student.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    private void generateID(){
        id++;
        this.studentID = year + "" + id;
    }

    public void enroll(){
        boolean loop = true;
        do {
            System.out.print("Enter course to enroll (Q to quit): ");
            Scanner in = new Scanner(System.in);
            String course = in.nextLine();
            if (!course.equals("Q")) {
                courses.add(course);
                tuitionBalance += costOfCourse;
            } else {
                break;
            }
        }while (loop);

    }

    public void viewBalance(){
        System.out.println("Current Balance: $" + tuitionBalance);
    }

    public void payTuition(){
        viewBalance();
        System.out.print("Enter your payment: $");
        Scanner in = new Scanner(System.in);
        int payment = in.nextInt();
        tuitionBalance -= payment;
        System.out.println("Thank you for your payment of: $" + payment);
        viewBalance();
    }

    @Override
    public String toString() {
        return
                firstName + " " + '\'' + lastName + '\'' +
                ", year: " + year +
                ", studentID: " + studentID + '\'' +
                ", courses: " + courses +
                ", tuitionBalance: $" + tuitionBalance
                ;
    }
}
