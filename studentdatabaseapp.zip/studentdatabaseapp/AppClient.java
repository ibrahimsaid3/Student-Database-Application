package studentdatabaseapp;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.awt.Color;
import java.awt.Dimension;

public class AppClient {

    private static JFrame dbFrame = new JFrame("Student Database Application");
    private static JLabel titleLabel;
    private static JPanel titlePanel;
    private static JPanel dataEntryPanel;
    private static JPanel courseSelectPanel;
    private static JButton enrollButton = new JButton("Enroll");
    private static JButton updateButton = new JButton("Update");
    private static JButton resetButton = new JButton("Reset");
    private static JButton deleteButton = new JButton("Delete");
    private static JButton quitButton = new JButton("Quit");
    private static JButton helpButton = new JButton("Help");
    private static JPanel listPanel = new JPanel(new FlowLayout());
    private static DefaultListModel nameListModel = new DefaultListModel();
    private static DefaultListModel idListModel = new DefaultListModel();
    private static DefaultListModel addressListModel = new DefaultListModel();
    private static DefaultListModel genderListModel = new DefaultListModel();
    private static JPanel idPanel = new JPanel(new BorderLayout());
    private static JPanel firstPanel = new JPanel(new BorderLayout());
    private static JPanel lastPanel = new JPanel(new BorderLayout());
    private static JPanel addPanel = new JPanel(new BorderLayout());
    private static JPanel genPanel = new JPanel(new BorderLayout());
    private static JLabel idLabel = new JLabel("Student ID:");
    private static JLabel firstNameLabel = new JLabel("First Name:");
    private static JLabel lastNameLabel = new JLabel("Last Name:");
    private static JLabel addressLabel = new JLabel("Address:");
    private static JLabel genderLabel = new JLabel("Gender: ");
    private static JTextField idField = new JTextField(16);
    private static JTextField firstNameField = new JTextField(16);
    private static JTextField lastNameField = new JTextField(16);
    private static JTextField addressField = new JTextField(16);
    private static String[] genderChoices = {"Select Gender", "Male", "Female"};
    private static JComboBox genderField = new JComboBox(genderChoices);
    private static JList nameList = new JList(nameListModel);
    private static JList idList = new JList(idListModel);
    private static JList addList = new JList(addressListModel);
    private static JList genList = new JList(genderListModel);
    private static JCheckBox mathCheck = new JCheckBox("Math");
    private static JCheckBox historyCheck = new JCheckBox("History");
    private static JCheckBox scienceCheck = new JCheckBox("Science");
    private static JCheckBox englishCheck = new JCheckBox("English");
    private static JCheckBox musicCheck = new JCheckBox("Music");
    private static JCheckBox compCheck = new JCheckBox("Computer Science");
    private static JCheckBox gymCheck = new JCheckBox("Physical Education");
    private static JCheckBox geoCheck = new JCheckBox("Geography");
    private static DefaultListModel compModel = new DefaultListModel();
    private static DefaultListModel mathModel = new DefaultListModel();
    private static DefaultListModel geoModel = new DefaultListModel();
    private static DefaultListModel musicModel = new DefaultListModel();
    private static DefaultListModel sciModel = new DefaultListModel();
    private static DefaultListModel gymModel = new DefaultListModel();
    private static DefaultListModel engModel = new DefaultListModel();
    private static DefaultListModel hisModel = new DefaultListModel();
    private static JList compList = new JList(compModel);
    private static JList geoList = new JList(geoModel);
    private static JList mathList = new JList(mathModel);
    private static JList musicList = new JList(musicModel);
    private static JList sciList = new JList(sciModel);
    private static JList gymList = new JList(gymModel);
    private static JList engList = new JList(engModel);
    private static JList hisList = new JList(hisModel);

    public AppClient(){
    }

    private void setDbFrameLayout(){
        dbFrame.getContentPane().setBackground(Color.BLUE);
    }

    private void titlePanelLayout(){
        titlePanel = new JPanel();
        titleLabel = new JLabel("Student Database Management System");
        titleLabel.setFont(new Font("Serif", Font.PLAIN, 28));
        titleLabel.setForeground(new Color(225, 173, 1));
        titlePanel.setBackground(Color.BLUE);
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        dbFrame.add(titlePanel, BorderLayout.NORTH);
    }

    private void dataEntryPanelLayout(){
        dataEntryPanel = new JPanel();
        dataEntryPanel.setLayout(new BoxLayout(dataEntryPanel, BoxLayout.PAGE_AXIS));
        infoPanelLayout();
        coursesPanelLayout();
        dbFrame.add(dataEntryPanel, BorderLayout.WEST);
    }

    private void infoPanelLayout(){
        idLabel.setDisplayedMnemonic(KeyEvent.VK_N);
        idLabel.setLabelFor(idField);
        idPanel.add(idLabel, BorderLayout.WEST);
        idPanel.add(idField, BorderLayout.LINE_END);
        dataEntryPanel.add(idPanel);

        firstNameLabel.setLabelFor(firstNameField);
        firstPanel.add(firstNameLabel, BorderLayout.WEST);
        firstPanel.add(firstNameField, BorderLayout.LINE_END);
        dataEntryPanel.add(firstPanel);

        lastNameLabel.setLabelFor(lastNameField);
        lastPanel.add(lastNameLabel, BorderLayout.WEST);
        lastPanel.add(lastNameField, BorderLayout.LINE_END);
        dataEntryPanel.add(lastPanel);

        addressLabel.setLabelFor(addressField);
        addPanel.add(addressLabel, BorderLayout.WEST);
        addPanel.add(addressField, BorderLayout.LINE_END);
        dataEntryPanel.add(addPanel);

        genderLabel.setLabelFor(genderField);
        genPanel.add(genderLabel, BorderLayout.WEST);
        genPanel.add(genderField);
        dataEntryPanel.add(genPanel);
    }

    private void coursesPanelLayout(){
        JLabel label = new JLabel("|-----------------Select a course-----------------|");
        JPanel labelPanel = new JPanel();
        labelPanel.add(label, BorderLayout.CENTER);
        dataEntryPanel.add(labelPanel);

        JPanel compPanel = new JPanel(new BorderLayout());
        compPanel.add(compCheck);
        dataEntryPanel.add(compPanel);

        JPanel mathPanel = new JPanel(new BorderLayout());
        mathPanel.add(mathCheck);
        dataEntryPanel.add(mathPanel);

        JPanel sciencePanel = new JPanel(new BorderLayout());
        sciencePanel.add(scienceCheck);
        dataEntryPanel.add(sciencePanel);

        JPanel geoPanel = new JPanel(new BorderLayout());
        geoPanel.add(geoCheck);
        dataEntryPanel.add(geoPanel);

        JPanel gymPanel = new JPanel(new BorderLayout());
        gymPanel.add(gymCheck);
        dataEntryPanel.add(gymPanel);

        JPanel engPanel = new JPanel(new BorderLayout());
        engPanel.add(englishCheck);
        dataEntryPanel.add(engPanel);

        JPanel hisPanel = new JPanel(new BorderLayout());
        hisPanel.add(historyCheck);
        dataEntryPanel.add(hisPanel);

        JPanel musicPanel = new JPanel(new BorderLayout());
        musicPanel.add(musicCheck);
        dataEntryPanel.add(musicPanel);

    }


    private void buttonControlLayout(){
        JPanel buttonControlPanel = new JPanel(new FlowLayout());
        buttonControlPanel.setBackground(Color.BLUE);


        ArrayList<JButton> buttons = new ArrayList<JButton>();
        buttons.add(enrollButton);
        buttons.add(updateButton);
        buttons.add(helpButton);
        buttons.add(resetButton);
        buttons.add(deleteButton);
        buttons.add(quitButton);

        for (JButton b: buttons){
            b.setBackground(new Color(225, 173, 1));
            b.setForeground(Color.BLUE);
            b.setFont(new Font("Times New Roman", Font.PLAIN, 14));
            buttonControlPanel.add(b);
        }

        dbFrame.add(buttonControlPanel, BorderLayout.SOUTH);


    }

    private void listLayout(){
        JPanel listPanel = new JPanel(new FlowLayout());

        nameListModel.addElement("Name");
        idListModel.addElement("Student ID");
        addressListModel.addElement("Address");
        genderListModel.addElement("Gender");

        compModel.addElement("Computer Science Enrollment");
        mathModel.addElement("Math Enrollment");
        sciModel.addElement("Science Enrollment");
        geoModel.addElement("Geography Enrollment");
        gymModel.addElement("Phys. Ed Enrollment");
        engModel.addElement("English Enrollment");
        hisModel.addElement("History Enrollment");
        musicModel.addElement("Music Enrollment");



        listPanel.add(nameList);
        listPanel.add(idList);
        listPanel.add(addList);
        listPanel.add(genList);
        listPanel.add(compList);
        listPanel.add(mathList);
        listPanel.add(sciList);
        listPanel.add(geoList);
        listPanel.add(gymList);
        listPanel.add(engList);
        listPanel.add(hisList);
        listPanel.add(musicList);

        JScrollPane scrollPane = new JScrollPane(listPanel);

        dbFrame.add(scrollPane, BorderLayout.CENTER);
    }

    private void actionCheckBoxListeners(){

    }


    private void actionButtonListeners(){
        enrollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String name = firstNameField.getText() + " " + lastNameField.getText();
                String id = idField.getText();
                String gender = (String) genderField.getSelectedItem();
                String address = addressField.getText();
                nameListModel.addElement(name);
                nameList = new JList(nameListModel);
                idListModel.addElement(id);
                idList = new JList(idListModel);
                genderListModel.addElement(gender);
                genList = new JList(genderListModel);
                addressListModel.addElement(address);
                addList = new JList(addressListModel);

                if (compCheck.isSelected()){
                    compModel.addElement("Enrolled");
                    compList = new JList(compModel);
                }
                else {
                    compModel.addElement("Not Enrolled");
                    compList = new JList(compModel);
                }

                if (mathCheck.isSelected()){
                    mathModel.addElement("Enrolled");
                    mathList = new JList(mathModel);
                }
                else {
                    mathModel.addElement("Not Enrolled");
                    mathList = new JList(mathModel);
                }

                if (scienceCheck.isSelected()){
                    sciModel.addElement("Enrolled");
                    sciList = new JList(sciModel);
                }
                else {
                    sciModel.addElement("Not Enrolled");
                    sciList = new JList(sciModel);
                }

                if (geoCheck.isSelected()){
                    geoModel.addElement("Enrolled");
                    geoList = new JList(geoModel);
                }
                else {
                    geoModel.addElement("Not Enrolled");
                    geoList = new JList(geoModel);
                }

                if (gymCheck.isSelected()){
                    gymModel.addElement("Enrolled");
                    gymList = new JList(gymModel);
                }
                else {
                    gymModel.addElement("Not Enrolled");
                    gymList = new JList(gymModel);
                }

                if (englishCheck.isSelected()){
                    engModel.addElement("Enrolled");
                    engList = new JList(engModel);
                }
                else {
                    engModel.addElement("Not Enrolled");
                    engList = new JList(engModel);
                }

                if (historyCheck.isSelected()){
                    hisModel.addElement("Enrolled");
                    hisList = new JList(hisModel);
                }
                else {
                    hisModel.addElement("Not Enrolled");
                    hisList = new JList(hisModel);
                }

                if (musicCheck.isSelected()){
                    musicModel.addElement("Enrolled");
                    musicList = new JList(musicModel);
                }
                else {
                    musicModel.addElement("Not Enrolled");
                    musicList = new JList(musicModel);
                }

                firstNameField.setText("");
                lastNameField.setText("");
                idField.setText("");
                addressField.setText("");
            }
        });

        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                nameListModel.removeAllElements();
                nameList = new JList(nameListModel);
                idListModel.removeAllElements();
                idList = new JList(idListModel);
                addressListModel.removeAllElements();
                addList = new JList(addressListModel);
                genderListModel.removeAllElements();
                genList = new JList(genderListModel);

                compModel.removeAllElements();
                compList = new JList(compModel);

                mathModel.removeAllElements();
                mathList = new JList(mathModel);

                sciModel.removeAllElements();
                sciList = new JList(sciModel);

                geoModel.removeAllElements();
                geoList = new JList(geoModel);

                gymModel.removeAllElements();
                gymList = new JList(gymModel);

                engModel.removeAllElements();
                engList = new JList(engModel);

                hisModel.removeAllElements();
                hisList = new JList(hisModel);

                musicModel.removeAllElements();
                musicList = new JList(musicModel);

                nameListModel.addElement("Name");
                idListModel.addElement("Student ID");
                addressListModel.addElement("Address");
                genderListModel.addElement("Gender");
                compModel.addElement("Computer Science Enrollment");
                mathModel.addElement("Math Enrollment");
                sciModel.addElement("Science Enrollment");
                geoModel.addElement("Geography Enrollment");
                gymModel.addElement("Phys. Ed Enrollment");
                engModel.addElement("English Enrollment");
                hisModel.addElement("History Enrollment");
                musicModel.addElement("Music Enrollment");

            }
        });

        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JFrame quitFrame = new JFrame();
                JButton yes = new JButton("Yes");
                JButton no = new JButton("No");
                yes.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent actionEvent) {
                        dbFrame.setVisible(false);
                        dbFrame.dispose();
                        quitFrame.setVisible(false);
                    }
                });
                no.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent actionEvent) {
                        quitFrame.setVisible(false);
                    }
                });
                JLabel message = new JLabel("Are you sure you want to quit?");
                JPanel layout = new JPanel(new FlowLayout());
                layout.add(message, BorderLayout.NORTH);


                layout.add(yes);
                layout.add(no);
                quitFrame.add(layout);
                quitFrame.setTitle("Quit?");
                quitFrame.setSize(200, 100);
                quitFrame.setVisible(true);
            }
        });

        helpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JFrame helpFrame = new JFrame();
                JPanel helpPanel = new JPanel();
                helpPanel.setLayout(new BoxLayout(helpPanel, BoxLayout.PAGE_AXIS));
                JLabel enrollLabel = new JLabel("Enroll Button: After setting up confidentials, click this button to enroll student into the database. ");
                JLabel updateLabel = new JLabel("Update Button: Click here to update data for any given student.");
                JLabel helpLabel = new JLabel("Help Button: Click here to pop-up this help page.");
                JLabel resetLabel = new JLabel("Reset Button: Click here to reset and clear all data in the database.");
                JLabel deleteLabel = new JLabel("Delete Button: Click here to delete a student from the database given the student ID.");
                JLabel quitLabel = new JLabel("Quit Button: Click here to quit the program.");
                helpPanel.add(enrollLabel);
                helpPanel.add(updateLabel);
                helpPanel.add(helpLabel);
                helpPanel.add(resetLabel);
                helpPanel.add(deleteLabel);
                helpPanel.add(quitLabel);

                helpFrame.add(helpPanel);
                helpFrame.setTitle("Help Page");
                helpFrame.pack();
                helpFrame.setVisible(true);
            }
        });


    }




    private void displayGUI() {
        setDbFrameLayout();
        titlePanelLayout();
        dataEntryPanelLayout();
        buttonControlLayout();
        actionButtonListeners();
        actionCheckBoxListeners();
        listLayout();
        dbFrame.pack();
        dbFrame.setVisible(true);
    }

    public static void main(String[] args) {
        AppClient appClient = new AppClient();
        appClient.displayGUI();
    }

    /*
    public static void main(String[] args) {
        System.out.print("Enter the number of new students to enroll: ");
        Scanner in = new Scanner(System.in);
        int numOfStudents = in.nextInt();
        Student[] students = new Student[numOfStudents];

        for (int i = 0; i < numOfStudents; i++){
            students[i] = new Student();
            students[i].enroll();
            students[i].payTuition();
            System.out.println(students[i].toString());
        }
    }

     */
}
